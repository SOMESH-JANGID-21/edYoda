import React from "react";
import { NavLink } from "react-router-dom";

function Menu(props){
    return(
        <nav className="navbar navbar-expand-md navbar-dark bg-white">
            <div className="container">
                <NavLink to={'/'} className = "navbar-brand"><img src="./images/EDYODA.jpg" alt="" /></NavLink>

                <button className="navbar-toggler" data-bs-toggle = "collapse" data-bs-target="#menu">
                    <span className="navbar-toggler-icon bg-dark"></span>
                </button>

                <div className="collapse navbar-collapse justify-content-between" id="menu">
                    <ul className="navbar-nav align-item-center">
                        <li className="nav-item">
                            <NavLink to={'/'} className = "nav-link text-dark pt-3 "><h6>Courses</h6></NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink to={'/'} className = "nav-link text-dark  pt-3"><h6>Programs</h6></NavLink>
                        </li>
                    </ul>
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <NavLink to={'/'} className = "nav-link text-dark me-5  pt-3"><h6>Login</h6></NavLink>
                        </li>
                        <li className="nav-item">
                            <button className="nav-link bg-primary rounded-pill text-white px-3 ">JOIN NOW</button>
                        </li>
                    </ul>
                </div>
            </div>

        </nav>
    )
}
export default Menu