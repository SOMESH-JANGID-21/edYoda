import React from 'react'

function Payment() {
  const [selectedPlan, setSelectedPlan] = React.useState(null);
  const [planPrice, setPlanPrice] = React.useState(0);


  return (
    <div className='container bg-white my-3 rounded' style={{width:500}}>
      <div className="row justify-content-around">
      <button className="bg-primary rounded-circle text-white px-3 mt-3 d-flex justify-content-center align-items-center" style={{ width: 30, height: 35 }}>1</button>
      <button className="bg-primary rounded-circle text-white px-3 mt-3 d-flex justify-content-center align-items-center" style={{ width: 30, height: 35 }}>2</button>
      </div>

      <div className="row d-flex justify-content-around">
      <div className="text-dark "style={{ width: 90 }} >Sign up</div>
      <div className="text-dark " style={{ width: 90}}>Subscribe</div>
      </div>
      
      <div className="row ">
      <h5 className="text-dark d-flex justify-content-around mt-3 " >Select your subscription plan</h5>
      </div>

      <div className="row d-flex justify-content-center">
      <div className="border border-dark rounded p-2 mt-2 d-flex justify-content-between" style={{width:420}}>
       <div> <input type="radio" disabled /> 12 Months Subscription <span className='text-danger'>(expired)</span></div>
        {/* <label htmlFor=""></label> */}
        <div>total ₹ 49</div>
      </div>
      </div>

      <div className="row d-flex justify-content-center">
      <div className="border border-dark rounded p-2 mt-4 d-flex justify-content-between" style={{width:420}}>
       <div> <input type="radio" name="plan" value="12" onChange={(e) => {
    setSelectedPlan(e.target.value);
    setPlanPrice(99);
  }} />
12 Months Subscription</div>
        {/* <label htmlFor=""></label> */}
        <div>total ₹ 99</div>
      </div>
      </div>

      <div className="row d-flex justify-content-center">
      <div className="border border-dark rounded p-2 mt-4 d-flex justify-content-between" style={{width:420}}>
       <div> <input type="radio" name="plan" value="6" onChange={(e) => {
    setSelectedPlan(e.target.value);
    setPlanPrice(60);
  }} />
6 Months Subscription</div>
        {/* <label htmlFor=""></label> */}
        <div>total ₹ 60</div>
      </div>
      </div>

      <div className="row d-flex justify-content-center">
      <div className="border border-dark rounded p-2 mt-4 d-flex justify-content-between" style={{width:420}}>
       <div> <input type="radio" name="plan" value="3" onChange={(e) => {
    setSelectedPlan(e.target.value);
    setPlanPrice(29);
  }} />
3 Months Subscription</div>
        {/* <label htmlFor=""></label> */}
        <div>total ₹ 29</div>
      </div>
      </div>

      <hr />

      <div className="row d-flex justify-content-center">
      <div style={{width:420}}>Subscription fee <span className='float-end'>₹ {planPrice * selectedPlan}</span></div>
      </div>

      <div className="row d-flex justify-content-center">
      <div className="border border-dark rounded pt-2 mt-4 text-danger" style={{width:420,background:'#DE4'}}>
       <div className='d-flex justify-content-between'>
          <div> Limmitade time offer</div>
          <div>total ₹ 80(12Months)</div>
       </div>
       <div className="row"><img src="./images/Icon6.png" alt="" style={{height:20,width:40,}}/><p style={{width:300}}>offer valit till 25th march</p></div>
      </div>
      </div>

      <div className="row mt-3 d-flex justify-content-center">
      <div style={{width:420}}>Total(Incl. of 18% gst) <span className='float-end'>₹ {planPrice * 1.18 + planPrice * selectedPlan }</span></div>
      </div>



      <div className="row d-flex justify-content-center">
      <div className="p-2 mt-4 d-flex justify-content-between" style={{width:420}}>
       <button className="btn btn-outline-danger" style={{width:200}}>Cancel</button>
       <button className="btn bg-success" style={{width:200}} disabled={!selectedPlan}>Payment</button>
      </div>
      </div>

      <div className="row d-flex justify-content-start pb-4 ">
      <img src="./images/Frame.png" alt="" style={{height:60,width:200,}}/>
      </div>

    </div>
  )
}

export default Payment
